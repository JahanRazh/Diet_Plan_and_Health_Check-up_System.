#pragma once
#include <string>

class Payment //Payment class //Part class for Apartment
{
private:
	int paymentID;
	string string_type;
		
public:
	Payment();
	Payment(int ppaymentID, int papartmentID);
	void confirmPayment();
	~Payment();
};

// Payment.cpp
#include "Payment.h"
Payment::Payment() {
}
Payment::Payment(int ppaymentID, int papartmentID) {
	paymentID = ppaymentID;
	apartmentID =
		apartmentID;
}
void Payment::confirmPayment() {

}
Payment::Payment() { 
}